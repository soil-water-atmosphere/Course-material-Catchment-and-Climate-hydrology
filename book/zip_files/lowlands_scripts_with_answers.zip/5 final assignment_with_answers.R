
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/PC_practical/WALRUS/R/")
setwd("M:/.../WALRUS_practical/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_BakelseAa_hour.dat", header=TRUE)


################
# Parameter sets
################

# specify how many parameter sets you have
N_pars = 2
N_pars = ...

# Define the parameters (cW, cV, cG, cQ, cS) and initial groundwater depth (dG0).
# Use vectors for each parameter to make different parameter sets.
pars_matrix = data.frame(cW=c(230,220), # change these numbers to your own parameter sets
                  cV=c(18,12), 
                  cG=c(7e6,8e6), 
                  cQ=c(30,40))
pars_matrix = data.frame(cW=c(...,...,...), 
                  cV=c(...,...,...),
                  cG=c(...,...,...),
                  cQ=c(...,...,...))


##########################################################
# Make a matrix to fill with different modelled discharges
##########################################################

# Make an empty matrix with as many columns as you need (number of 
# parameter sets times)
# and 72 rows (3 days of 24 hours).
M = matrix(ncol=N_pars, nrow=72)
M = ...



######################################
# Run for-loop over all parameter sets
######################################

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2011080000, 2011090000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)

for(i in 1:N_pars)
{
  # Select the right row from the parameter matrix and use the catchment
  # characteristics belonging to the Bakelse Aa catchment.
  pars = data.frame(pars_matrix[i,], Gfrac=1, cD=1200, cS=1.3, aS=0.015, st="sand")
   
  # Run the model. 
  mod = WALRUS_loop(pars=pars)
  
  # If you want, you can save the output.
  name = paste("hindcast_par", i, sep="")
  
  # Postprocessing: create datafiles and show figures.
  WALRUS_postprocessing(o=mod, pars=pars, n=name)
  
  # Put the modelled discharge in the collection matrix.
  M[,i] = mod$Q[forc$date >= 2011081800 & forc$date < 2011082100]
}



###############
# Plot ensemble
###############

par(mfrow=c(1,1))

# plot observed discharge
plot(c(1:(24*17)), data$Q[data$date >= 2011080000 & data$date < 2011081800], 
     type="l", xlim=c(0,(24*20)), ylim=c(0,max(M)), xlab="Time [h]", ylab="Q [mm/h]")

# plot lines for each parameter set
for(i in 1:ncol(M))
{
  lines(c((24*17):(24*20-1)), M[,i], col="dodgerblue")
}


####################################
# Compute percentiles 
####################################

# Use the functions apply and quantile to compute the 25th, 50th and 75th percentiles.
# Look in the help function how to use "apply" and "quantile".
Q25 = apply(M, MARGIN=1, FUN=quantile, probs=0.25)
Q25 = ...
Q50 = apply(M, MARGIN=1, FUN=quantile, probs=0.5)
Q50 = ...
Q75 = apply(M, MARGIN=1, FUN=quantile, probs=0.75)
Q75 = ...

# Function to copy items from R to clipboard:
write.excel = function(x,row.names=FALSE,col.names=TRUE) { 
  write.table(x, "clipboard",sep="\t", row.names=row.names, col.names=col.names) 
}

# Call the function.
write.excel(data.frame(Q25,Q50,Q75))

# Then paste in the Google sheet.



