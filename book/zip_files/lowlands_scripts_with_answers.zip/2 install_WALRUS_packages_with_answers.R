
# install two packages which WALRUS needs in the background
# (ignore warnings)

install.packages("zoo")
install.packages("shiny")
install.packages("minpack.lm")


# Change working directory to where the WALRUS_practical folder is located:
setwd("D:/Dropbox/CH/PC_practical/WALRUS/R/")
setwd("M:/.../WALRUS_practical/")

# Install WALRUS package
install.packages("source_files/WALRUS_1.10.tar.gz", repos = NULL, type = "source")


# # In case you want to install directly from github:
# 
# # install package to download from github
# install.packages("devtools")
# 
# # load the devtools package (necessary to download from GitHub)
# library(devtools)
# 
# # install latest version of WALRUS directly from GitHub
# install_github("ClaudiaBrauer/WALRUS")

