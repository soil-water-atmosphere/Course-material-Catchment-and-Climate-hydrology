
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/CH/PC_practical/WALRUS/R/")
setwd("M:/.../WALRUS_practical/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_BakelseAa_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2010040000, 2011040000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=24)


###############################
# Parameters and initial values
###############################

# Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
# catchment characteristics (cD, aS, soil type).
pars = data.frame(cW=..., cG=..., cQ=..., 
                  cV=10, cS=1.3, Gfrac=0.2, cD=1200, aS=0.015, st="sand")
pars = data.frame(cW=230, cV=18, cG=7e6, cQ=30, 
                  cS=1.3, Gfrac=0.2, cD=1200, aS=0.015, st="sand")



#####
# Run
#####

# Run the model. 
mod = WALRUS_loop(pars=pars)


##########################
# Output files and figures
##########################

# Give the run a logical name. This will be used for the output data files and figures.
name = "manual_calibration_1"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod, pars=pars, n=name)

