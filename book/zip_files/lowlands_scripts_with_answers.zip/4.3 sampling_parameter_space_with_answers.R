
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/CH/PC_practical/WALRUS/R/")
setwd("D:/education/CH/PC_practical/WALRUS/R/")
setwd("M:/.../WALRUS_practical/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_BakelseAa_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2010040100, 2011040100)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)
WALRUS_preprocessing_calibration()



##########################
# Monte Carlo calibration
##########################

# # Load package to compute Kling-Gupta efficiency.
# library(hydroGOF)
# 
# # Make many (in this example 1000) random parameter sets within certain limits.
# cW  = runif(1000, min=200, max=300)
# cG  = runif(1000, min=1e5, max=2e7)
# cQ  = runif(1000, min=1  , max=100)
# 
# # Make an empty vector to store mean sums of squares during for-loop.
# SS  = c()
# KGE = c()
# 
# # Run a for-loop over all parameter sets and run WALRUS in every iteration.
# for(i in 1:1000)
# {
#   print(i)
#   # look up the parameter set for this iteration
#   parameters = data.frame(cW=cW[i], cG=cG[i], cQ=cQ[i], cV=10, cS=1.3,
#                           Gfrac=0.2, cD=1200, aS=0.015, st="sand")
# 
#   # run WALRUS
#   modeled    = WALRUS_loop(pars=parameters)
# 
#   # Compute and store the mean sum of squares.
#   SS [i]     = mean((Qobs_forNS-modeled$Q)^2)
#   KGE[i]     = KGE(sim=modeled$Q, obs=Qobs_forNS, na.rm=T)
# }
# 
# # Write the results to file: parameter values and belonging sum of squares.
# write.table(data.frame(cbind(cW, cG, cQ, SS, KGE)), "output/pars_MC_BakelseAa.dat")


##############################
# Read output from Monte Carlo
##############################

# read output from Monte Carlo run
MC = read.table("output/pars_MC_BakelseAa.dat", header=TRUE)

# dotty plots: plot one parameter on the x-axis and goodness of fit on the y-axis
plot(MC$cW, MC$SS, col="purple")
plot(MC$cG, MC$SS, col="orange")
plot(MC$cQ, MC$SS, col="forestgreen")

# to select the best 1%
# best_pars = MC[MC$SS < quantile(MC$SS,0.001),] 
# select best 10, when you don't have 1000 runs.
best_pars = MC[order(MC$SS)[1:10],]

# write best parameter sets to file
write.table(best_pars, "output/best_pars_MC_BakelseAa.dat", row.names=FALSE)


###############################
# Parameters and initial values
###############################

# make empty vector for modelled discharge
Qmod = matrix(ncol=10, nrow=nrow(forc)+1)

for(i in 1:10)
  {
  print(i)
  
  # Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
  # catchment characteristics (cD, aS, soil type).
  pars = data.frame(cW=best_pars$cW[i], cV=10, 
                    cG=best_pars$cG[i], cQ=best_pars$cQ[i], 
                    cS=1.3, Gfrac=0.2, cD=1200, aS=0.015, st="sand")
  
  #####
  # Run
  #####
  
  # Run the model. 
  mod = WALRUS_loop(pars=pars)
  
  # save modelled Q in the matrix
  Qmod[,i] = mod$Q
  }


######
# Plot
######

# plot observed discharge
plot(c(0,forc$Q), type="l")

# plot lines for eack parameter set
for(i in 1:10)
  {
  lines(Qmod[,i], col="dodgerblue")
  }

# draw observed discharge on top
lines(c(0,forc$Q))













