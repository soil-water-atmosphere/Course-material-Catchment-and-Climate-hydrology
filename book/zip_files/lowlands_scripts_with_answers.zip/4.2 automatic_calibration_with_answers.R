
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)
library(minpack.lm)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/CH/PC_practical/WALRUS/R/")
setwd("M:/.../WALRUS_practical/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_BakelseAa_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2010090000, 2010120000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=3)
WALRUS_preprocessing_calibration()


#####################
# Prepare calibration
#####################

# Give the run a logical name.
name = "automatic_calibration"

# Define initial and boundary values for the parameters you want to calibrate.
# You can also calibrate the initial values (if you want).
par_start = c(200, 30e6 , 20 ) 
par_LB    = c(100, 0.1e6, 1  )
par_UB    = c(400, 100e6, 100)

# to normalize parameters (better for optimization technique)
norm      = c(200, 50e6 , 50 ) 


# Rewrite the model such that the output is a vector of residuals: Qobs-Qmod.
WALRUS_for_optim = function(par)
{
  fit_pars = data.frame(cW=par[1]*norm[1], cV=10, cG=par[2]*norm[2], cQ=par[3]*norm[3], 
                        cS=1.3, Gfrac=0.2, cD=1200, aS=0.015, st="sand")
  mod = WALRUS_loop(pars=fit_pars)
  return(Qobs_forNS-mod$Q)
}

# Test if the starting model parameters yield reasonable results. 
fit_pars = data.frame(cW=par_start[1], cV=10, cG=par_start[2], cQ=par_start[3], 
                      cS=1.3, Gfrac=0.2, cD=1200, aS=0.015, st="sand")
mod      = WALRUS_loop(pars=fit_pars)
WALRUS_postprocessing(o=mod, pars=fit_pars, n=name)


#############
# Calibration
#############

# This is the Levenberg-Marquardt optimization algorithm
# which will minimize the sum of squares of the residuals. 
# Increasing nprint will give more information.
# Maxiter is the maximum number of iterations.
cal = nls.lm(par=par_start/norm, lower=par_LB/norm, upper=par_UB/norm, fn=WALRUS_for_optim, 
             control=nls.lm.control(nprint=1,maxiter=10))


#########################
# Run with optimal values
#########################

# Retrieve the optimal parameter values found in the calibration procedure.
opt_pars = coef(cal) * norm

# Write the optimate parameter values in a data frame
opt_pars = data.frame(cW=opt_pars[1], cV=10, cG=opt_pars[2], cQ=opt_pars[3], 
                        cS=1.3, Gfrac=0.2, cD=1200, aS=0.015, st="sand")

# Run once more with best parameters to create data files and plot figures.
mod = WALRUS_loop(pars=opt_pars)
WALRUS_postprocessing(o=mod, pars=opt_pars, n=name)

