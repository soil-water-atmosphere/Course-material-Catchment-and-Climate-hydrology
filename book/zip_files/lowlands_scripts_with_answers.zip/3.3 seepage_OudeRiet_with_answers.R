
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/CH/PC_practical/WALRUS/R/")
setwd("M:/.../WALRUS_practical/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_OudeRiet_day.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 20100400, 20110400)

# add seepage: add a column to the data frame forc called fXG
...
forc$fXG   = 2   # mm/d

# add a constant threshold for surface water (weir level)
forc$hSmin = 500 # mm

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)


###############################
# Parameters and initial values
###############################

# Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
# catchment characteristics (cD, aS, soil type).
pars = data.frame(cW=250, cV=10, cG=20e6, cQ=25, cS=2,
                  dG0=350, cD=2000, aS=0.02, st="cal_C")


#####
# Run
#####

# Run the model. 
mod = WALRUS_loop(pars=pars)


##########################
# Output files and figures
##########################

# Give the run a logical name. This will be used for the output data files and figures.
name = "seepage_OudeRiet"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod, pars=pars, n=name)


#########################
# Scenario double seepage
#########################

# copy the data set
forc2 = forc

# change the inlet time series
...
forc2$fXG = forc$fXG * 2

# do the preprocessing again
...
WALRUS_preprocessing(f=forc2, dt=1)

# rerun the model (lines 50, 58, 61)
mod = WALRUS_loop(pars=pars)
name = "seepage_double_OudeRiet"
WALRUS_postprocessing(o=mod, pars=pars, n=name)


#####################
# Scenario no seepage
#####################

# copy the data set
forc3 = forc

# change the inlet time series
...
forc3$fXG = 0

# do the preprocessing again
...
WALRUS_preprocessing(f=forc3, dt=1)

# rerun the model (lines 50, 58, 61)
mod = WALRUS_loop(pars=pars)
name = "seepage_zero_OudeRiet"
WALRUS_postprocessing(o=mod, pars=pars, n=name)





