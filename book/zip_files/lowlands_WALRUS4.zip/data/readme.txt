These data are prepared for a short course on WALRUS. 
Some of the data sets are not free, so please don't distribute them further.
Some of the data sets are not validated and may contain errors,
so don't use them for other purposes. 

P, ETpot, Q, fXS and fXG are in mm/h.
hSmin and dG are in mm.
T is in degrees C.



